package com.example.mymusic;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

import static com.example.mymusic.R.color.colorPrimary;

public class PlayerActivity extends AppCompatActivity {
    Button bn,bpr,bpa;
    TextView songtextlabel;
    SeekBar songseekBar;

    static MediaPlayer mymediaplayer;
    int pos;
    String sname;
    ArrayList<File> mySongs;
    Thread upadteseekBar;


    @SuppressLint("NewApi")
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        bn = (Button) findViewById(R.id.next);
        bpr = (Button) findViewById(R.id.previous);
        bpa = (Button) findViewById(R.id.pause);
        songtextlabel = (TextView) findViewById(R.id.songlabel);
        songseekBar = (SeekBar) findViewById(R.id.seekBar);

        getSupportActionBar().setTitle("Now playing");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        upadteseekBar = new Thread(){
            @Override
            public void run() {
                int totalDuration = mymediaplayer.getDuration();
                int currentpos = 0;

                while(currentpos < totalDuration){
                    try{
                        sleep(500);
                        currentpos = mymediaplayer.getCurrentPosition();
                        songseekBar.setProgress(currentpos);
                    }
                    catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        };


        if (mymediaplayer!=null){
            mymediaplayer.stop();
            mymediaplayer.release();
        }
        Intent i = getIntent();
        Bundle bundle = i.getExtras();

        mySongs = (ArrayList) bundle.getParcelableArrayList("songs");
        sname = mySongs.get(pos).getName().toString();
        String songname =i.getStringExtra("songname");
        songtextlabel.setText(songname);
        songtextlabel.setSelected(true);


        pos = bundle.getInt("posi",0);
        Uri u = Uri.parse(mySongs.get(pos).toString());

        mymediaplayer = MediaPlayer.create(getApplicationContext(),u);

        mymediaplayer.start();
        songseekBar.setMax(mymediaplayer.getDuration());

        upadteseekBar.start();

        songseekBar.getProgressDrawable().setColorFilter(getResources().getColor(colorPrimary), PorterDuff.
                Mode.MULTIPLY);
        songseekBar.getThumb().setColorFilter(getResources().getColor(R.color.colorPrimary),PorterDuff.Mode.SRC_IN);

        songseekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                mymediaplayer.seekTo(seekBar.getProgress());
            }
        });

        bpa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                songseekBar.setMax(mymediaplayer.getDuration());

                if(mymediaplayer.isPlaying()){

                    bpa.setBackgroundResource(R.drawable.icon_play);
                    mymediaplayer.pause();
                }
                else{
                    bpa.setBackgroundResource(R.drawable.icon_pause);
                    mymediaplayer.start();
                }
            }
        });
        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mymediaplayer.stop();
                mymediaplayer.release();
                pos = ((pos+1)%mySongs.size());

                Uri u = Uri.parse(mySongs.get(pos).toString());
                mymediaplayer = MediaPlayer.create(getApplicationContext(),u);
                sname = mySongs.get(pos).getName().toString();
                songtextlabel.setText(sname);
                mymediaplayer.start();

            }
        });

        bpr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mymediaplayer.stop();
                mymediaplayer.release();

                pos = ((pos-1)<0)?(mySongs.size()-1):(pos-1);

                Uri u = Uri.parse(mySongs.get(pos).toString());
                mymediaplayer = MediaPlayer.create(getApplicationContext(),u);
                sname = mySongs.get(pos).getName().toString();
                songtextlabel.setText(sname);
                mymediaplayer.start();

            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}